package week4_TranKhacLinh_2001040121;

public class PrimeList {
    
}
